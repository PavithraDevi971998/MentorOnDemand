package com.mod.controller;

import org.springframework.stereotype.Controller;

@Controller
public class LoginControllerImpl {

}
