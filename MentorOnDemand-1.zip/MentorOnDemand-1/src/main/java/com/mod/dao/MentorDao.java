package com.mod.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mod.model.Mentor;
import com.mod.model.User;
@Repository
public interface MentorDao extends JpaRepository<Mentor, Integer>{

	
	List<Mentor> findByemail(String email);

	List<Mentor> findBytechnology(String technology);

	List<Mentor> findByfromTime(String fromTime);

	Mentor findBymentorId(int id);

}
