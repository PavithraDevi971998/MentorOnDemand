package com.mod.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mod.model.Skills;

public interface SkillDao extends JpaRepository<Skills,Integer>{

}
